﻿namespace Movil_Servicio_DB_Nido
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
