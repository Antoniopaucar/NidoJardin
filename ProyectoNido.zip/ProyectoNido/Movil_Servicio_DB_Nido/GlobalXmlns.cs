[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "Movil_Servicio_DB_Nido")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "Movil_Servicio_DB_Nido.Pages")]
