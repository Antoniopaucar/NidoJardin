namespace Movil_Servicio_DB_Nido;

public partial class SelectChildPage : ContentPage
{
	public SelectChildPage()
	{
		InitializeComponent();
	}
}