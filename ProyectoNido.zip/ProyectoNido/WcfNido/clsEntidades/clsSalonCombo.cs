﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clsEntidades
{
    public class clsSalonCombo
    {
        public int Id_Salon { get; set; }
        public string Nombre { get; set; }
    }
}
