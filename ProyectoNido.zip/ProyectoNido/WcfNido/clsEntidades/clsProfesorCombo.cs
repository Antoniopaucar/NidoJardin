﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clsEntidades
{
    public class clsProfesorCombo
    {
        public int Id_Profesor { get; set; }
        public string NombreCompleto { get; set; }
    }
}
